#!/bin/bash
export CLOCK_FREQ_MHZ=100
